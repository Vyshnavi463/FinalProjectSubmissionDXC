package com.pro.pp.dao;

import java.util.List;

import com.pro.pp.entity.Pets;

public interface Petservice {
	public boolean addpet(Pets pets);
	public List<Pets> displayallpets();
	public List<Pets> searchbyage(int i);
	public List<Pets>  searchbyplace(String s);
	public List<Pets>  searchbyprice(int i,int j);
	public List<Pets>  searchbybreed(String s);
}
