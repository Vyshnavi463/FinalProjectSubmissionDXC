package com.pro.pp.dao;

public interface Lvalidate {
	public String userlogin(String s1, String s2);
}
