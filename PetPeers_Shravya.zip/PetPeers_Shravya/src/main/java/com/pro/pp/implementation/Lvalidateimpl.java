package com.pro.pp.implementation;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.pro.pp.dbconnection.DbConnection;
import com.pro.pp.entity.Petuser;

public class Lvalidateimpl {
	DbConnection db=new DbConnection();
	Session ses=db.getses();
	public String userlogin(String s1, String s2) {
		// TODO Auto-generated method stub
					Transaction tx=ses.beginTransaction();
						String st=null;
					  Query qr=ses.createQuery("from Petuser");
					
					   List<Petuser> l=qr.list();
					   Iterator<Petuser> it=l.iterator();
					 while(it.hasNext()) {
						 Petuser obj=(Petuser)it.next();
						 System.out.println(obj);
						 if(obj.getUname().equals(s1) && obj.getPass().equals(s2)) {
							 st=obj.getUname();
							 break;
						 }
						 
					 }
					 System.out.println(st);
		return st;
	}
}
