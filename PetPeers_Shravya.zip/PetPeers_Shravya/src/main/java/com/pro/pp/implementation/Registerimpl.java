package com.pro.pp.implementation;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.pro.pp.dao.Register;
import com.pro.pp.dbconnection.DbConnection;
import com.pro.pp.entity.Petuser;

public class Registerimpl implements Register{
	DbConnection db=new DbConnection();
	Session ses=db.getses();
	@Override
	public boolean adduser(String s1, String s2) {
		// TODO Auto-generated method stub
		Transaction tx=ses.beginTransaction();
		Petuser obj=new Petuser();
		obj.setUname(s1);
		obj.setPass(s2);
		ses.save(obj);
		tx.commit();
		return true;
	}

	@Override
	public void addpet() {
		// TODO Auto-generated method stub
		
	}

}
