package com.pro.pp.implementation;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.transaction.annotation.Transactional;

import com.pro.pp.dao.Petservice;
import com.pro.pp.dbconnection.DbConnection;
import com.pro.pp.entity.Addtocart;
import com.pro.pp.entity.Pets;

public class Petserviceimpl implements Petservice{
	DbConnection db=new DbConnection();
	Session ses=db.getses();
	@Override
	public boolean addpet(Pets pets) {
		// TODO Auto-generated method stub
		try {
			Transaction tx=ses.beginTransaction();
			Pets user = new Pets();
			/*
			 * InputStream inputStream = this.getClass() .getClassLoader()
			 * .getResourceAsStream(pets.);
			 * 
			 * if(inputStream == null) { fail("Unable to get resources"); }
			 * 
			 * user.setImg(IOUtils.toByteArray(inputStream));
			 */

			ses.save(pets);
			tx.commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public List<Pets> displayallpets() {
		// TODO Auto-generated method stub
		Criteria cr= ses.createCriteria(Pets.class);
		List<Pets> l=cr.list();	
	
			return l;
	}

	@Override
	public List<Pets> searchbyage(int i) {
		// TODO Auto-generated method stub
		 Query q=ses.createQuery("from Pets p where p.age =:myage");
	      q.setInteger("myage", i);
	      List<Pets> al= q.list();
	      System.out.println(al);
	  return al;
	}

	@Override
	public List<Pets> searchbyplace(String s) {
		// TODO Auto-generated method stub
		 Query q=ses.createQuery("from Pets p where p.place =:myplace");
	      q.setString("myplace", s);
	      List<Pets> al= q.list();
	      System.out.println(al);
	  return al;
	}

	@Override
	public List<Pets> searchbyprice(int i, int j) {
		 Query q=ses.createQuery("from Pets p where p.price between :myprice1 and :myprice2 order by p.price");
		 q.setInteger("myprice1", i);
		 q.setInteger("myprice2", j);
	      List<Pets> al= q.list();
	      System.out.println(al);
	  return al;
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Pets> searchbybreed(String s) {
		// TODO Auto-generated method stub
		 Query q=ses.createQuery("from Pets p where p.breed =:mybreed");
	      q.setString("mybreed", s);
	      List<Pets> al= q.list();
	      System.out.println(al);
	  return al;
	}

	public List<Addtocart> addtocart(String s1, String s2, int i, String s3, float j, int k, String s4) {
		// TODO Auto-generated method stub

			Transaction tx=ses.beginTransaction();
			Addtocart a=new Addtocart();
			a.setPetname(s1);
			a.setBreed(s2);
			a.setAge(i);
			a.setPlace(s3);
			a.setPhnno(k);
			a.setPrice(j);
			a.setEmail(s4);
			ses.save(a);
			tx.commit();
			Criteria cr= ses.createCriteria(Addtocart.class);
			List<Addtocart> l=cr.list();	
		
				return l;
		
	}

	public List<Addtocart> displaycart() {
		// TODO Auto-generated method stub
		Criteria cr= ses.createCriteria(Addtocart.class);
		List<Addtocart> l=cr.list();	
	
			return l;
	}
	
	public List<Addtocart> delincart(String s1) {
		// TODO Auto-generated method stub
		
		Transaction tx=ses.beginTransaction();
		Addtocart a =new Addtocart();
	      a.setPetname(s1);
	      ses.delete(a);
	     tx.commit();
	      Criteria cr= ses.createCriteria(Addtocart.class);
			List<Addtocart> l=cr.list();	
		
				return l;
	}

	public List billamount() {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				 Query q=ses.createQuery("select sum(price) from Addtocart p");
			     // q.setString("mybreed", s);
				 List l = q.list();
				return l;
			 
	}

}
