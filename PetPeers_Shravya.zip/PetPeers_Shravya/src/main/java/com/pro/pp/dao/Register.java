package com.pro.pp.dao;

public interface Register {
 public boolean adduser(String s1,String s2);
 public void addpet();
}
