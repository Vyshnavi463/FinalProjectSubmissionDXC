package com.pro.pp.dbconnection;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class DbConnection {
	SessionFactory sfact=null;
	Session ses=null;
	Transaction tx=null;
	
	public Session getses() {
		
		sfact=new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory();
		
		ses=sfact.openSession();
		
		return ses;
	}
}
