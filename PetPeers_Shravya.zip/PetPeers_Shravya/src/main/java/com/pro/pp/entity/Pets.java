package com.pro.pp.entity;

import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="pets")
public class Pets {
	//int petid;
	String petname;
	String breed;
	int age;
	String place;
	float price;
	int phnno;
	String email; 
	Blob img;
	
	@Column(name="img") 
	public Blob getImg() {
		return img;
	}
	public void setImg(Blob img) {
		this.img = img;
	}
	public Pets() {
		super();
	}
	public Pets(String petname, String breed, int age, String place, float price, int phnno, String email, Blob img) {
		super();
		//this.petid = petid;
		this.petname = petname;
		this.breed = breed;
		this.age = age;
		this.place = place;
		this.price = price;
		this.phnno = phnno;
		this.email = email;
		this.img=img;
	}
	@Id
	/*
	 * @Column(name="petid", nullable=false) public int getPetid() { return petid; }
	 * public void setPetid(int petid) { this.petid = petid; }
	 */
	@Column(name="petname", nullable=false) 
	public String getPetname() {
		return petname;
	}
	public void setPetname(String petname) {
		this.petname = petname;
	}
	@Column(name="breed", nullable=false) 
	public String getBreed() {
		return breed;
	}
	public void setBreed(String breed) {
		this.breed = breed;
	}
	@Column(name="age", nullable=false) 
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Column(name="place", nullable=false) 
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	@Column(name="price", nullable=false) 
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	@Column(name="phnno", nullable=false) 
	public int getPhnno() {
		return phnno;
	}
	public void setPhnno(int phnno) {
		this.phnno = phnno;
	}
	@Column(name="email", nullable=false) 
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
