package com.pro.pp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="petuser")
public class Petuser {
	public Petuser() {
		super();
	}
	String uname;
	String pass; 
	
	public Petuser(String uname, String pass) {
		super();
		this.uname = uname;
		this.pass = pass;
	}
	@Id
	@Column(name="uname",unique=true, nullable=false) 
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	@Column(name="pass", nullable=false) 
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	
}
