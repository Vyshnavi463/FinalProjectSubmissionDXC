package com.pro.pp.controller;

import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pro.pp.entity.Addtocart;
import com.pro.pp.entity.Pets;
import com.pro.pp.implementation.Lvalidateimpl;
import com.pro.pp.implementation.Petserviceimpl;
import com.pro.pp.implementation.Registerimpl;

@Controller
public class PetsAppController {
	
	@RequestMapping(value="reg")
	public ModelAndView home() {
		return new ModelAndView("registration");
	}
	@RequestMapping(value="reg.db")
	public ModelAndView regdb(	@RequestParam("u") String s1,
								@RequestParam("p") String s2) {
		Registerimpl r=new Registerimpl();
		boolean page=r.adduser(s1, s2);
		if(page) {
		return new ModelAndView("success");
		}
		else {
			return new ModelAndView("failure");
		}
	}
	@RequestMapping(value="login")
	public ModelAndView home1() {
		return new ModelAndView("login");
	}
	@RequestMapping(value="login.db")
	public ModelAndView logindb(	@RequestParam("u") String s1,
								@RequestParam("p") String s2) {
		Lvalidateimpl l=new Lvalidateimpl();
		String str=l.userlogin(s1, s2);
		if(str!=null) {
		return new ModelAndView("userhome","str",str);
		}
		else {
			return new ModelAndView("failure");
		}
	}
	@RequestMapping(value="addpet")
	public ModelAndView addpet() {
		return new ModelAndView("Addpet");
	}
	@RequestMapping(value="addpet.db",method=RequestMethod.POST)
	public ModelAndView addpetdb(@ModelAttribute("pets")Pets pets) {
		Petserviceimpl p=new Petserviceimpl();
		boolean page=p.addpet(pets);
				if(page) {
		return new ModelAndView("success");}
				else {
					return new ModelAndView("failure");
				}
	}
	@RequestMapping(value="byage")
	public ModelAndView byage() {
		return new ModelAndView("byage");
	}
	@RequestMapping(value="byage.db")
	public ModelAndView byagedb(@RequestParam("age") int i) {
		Petserviceimpl p=new Petserviceimpl();
		List<Pets> l=p.searchbyage(i);
		return new ModelAndView("display","lm",l);
	}
	@RequestMapping(value="byplace")
	public ModelAndView byage1() {
		return new ModelAndView("byplace");
	}
	@RequestMapping(value="byplace.db")
	public ModelAndView place(@RequestParam("place") String s) {
		Petserviceimpl p=new Petserviceimpl();
		List<Pets> l=p.searchbyplace(s);
		return new ModelAndView("display","lm",l);
	}
	@RequestMapping(value="bybreed")
	public ModelAndView byage2() {
		return new ModelAndView("bybreed");
	}
	@RequestMapping(value="bybreed.db")
	public ModelAndView breed(@RequestParam("breed") String s) {
		Petserviceimpl p=new Petserviceimpl();
		List<Pets> l=p.searchbybreed(s);
		return new ModelAndView("display","lm",l);
	}
	@RequestMapping(value="byprice")
	public ModelAndView byprice() {
		return new ModelAndView("byprice");
	}
	@RequestMapping(value="byprice.db")
	public ModelAndView price(@RequestParam("low") int i,@RequestParam("high") int j) {
		Petserviceimpl p=new Petserviceimpl();
		List<Pets> l=p.searchbyprice(i, j);
		return new ModelAndView("display","lm",l);
	}
	@RequestMapping(value="viewpets")
	public ModelAndView byall() {
		Petserviceimpl p=new Petserviceimpl();
		List<Pets> l=p.displayallpets();
		return new ModelAndView("display","lm",l);
		
	}
	@RequestMapping(value="addtocart",method=RequestMethod.POST)
	public ModelAndView cart(@RequestParam("petname") String s1,
								@RequestParam("breed") String s2,
								@RequestParam("age") int i,
								@RequestParam("place") String s3,
								@RequestParam("price") float j,
								@RequestParam("phnno") int k,
								@RequestParam("email") String s4
								) {
		Petserviceimpl p=new Petserviceimpl();
		List<Addtocart> l=p.addtocart(s1,s2,i,s3,j,k,s4);
		return new ModelAndView("cart","lm",l);
	}
	@RequestMapping(value="cart")
	public ModelAndView bycart() {
		Petserviceimpl p=new Petserviceimpl();
		List<Addtocart> l=p.displaycart();
		return new ModelAndView("cart","lm",l);
		
	}
	@RequestMapping(value="delincart",method=RequestMethod.POST)
	public ModelAndView cart(@RequestParam("petname") String s1
								
								) {
		Petserviceimpl p=new Petserviceimpl();
		List<Addtocart> l=p.delincart(s1);
		return new ModelAndView("cart","lm",l);
	}
	@RequestMapping(value="amount")
	public ModelAndView bycaart() {
		Petserviceimpl p=new Petserviceimpl();
		List l=p.billamount();
		return new ModelAndView("bill","m",l);
		
	}
}
