package com.dxc.pp.validator;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;

import com.dxc.pp.hib.HibernateConnection;
import com.dxc.pp.model.User;

public class SecurityService {
	public boolean authenticateUser(String username, String password) {
		boolean t = false;
		//System.out.print(username);
		//System.out.print(password);
		HibernateConnection hc= new HibernateConnection();
		Session ses = hc.getSession();
		Criteria c= ses.createCriteria(User.class);
		List l= c.list();
		Iterator i = l.iterator();
		while(i.hasNext()){
			User u = (User) i.next();
			if((username.equals(u.getUsername())) && (password.equals(u.getUserPassword()))) {
			t = true;	
			//System.out.println("true");
			}
		   // System.out.println("false");
			}
	return t;
	}
}
