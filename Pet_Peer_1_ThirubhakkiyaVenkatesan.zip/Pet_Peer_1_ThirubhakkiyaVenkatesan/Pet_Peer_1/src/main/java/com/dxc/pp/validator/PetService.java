package com.dxc.pp.validator;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.criterion.Restrictions;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.dxc.pp.hib.HibernateConnection;
import com.dxc.pp.model.Pet;
import com.dxc.pp.validator.service.Petservice;

public class PetService implements Petservice{
	public void savePet(Pet pet) {
		SessionFactory sfact= new AnnotationConfiguration().configure("hibernate.cfg2.xml").buildSessionFactory();
		 Session ses=sfact.openSession();

		ses.save(pet);
		Transaction t =ses.beginTransaction();
		t.commit();
	}

	@Override
	public List getAllPets() {
		// TODO Auto-generated method stub
		HibernateConnection hc = new HibernateConnection();
		Session ses=hc.getSession();
		Criteria c= ses.createCriteria(Pet.class);
		List l = c.list();
		return l;
	}

	@Override
	public List sortBybreed(String breed) {
		// TODO Auto-generated method stub
		HibernateConnection hc = new HibernateConnection();
		Session ses= hc.getSession();
		Criteria c = ses.createCriteria(Pet.class);
		c.add(Restrictions.eq("breeds", breed));
		List l =c.list();
	
		return l;
	}

	@Override
	public List byLocation(String location) {
		// TODO Auto-generated method stub
		HibernateConnection hc = new HibernateConnection();
		Session ses= hc.getSession();
		Criteria c = ses.createCriteria(Pet.class);
		c.add(Restrictions.eq("place",location));
		List l = c.list();
		
		return l;
	}

	@Override
	public void imgUpload(String path, String name,CommonsMultipartFile file) {
		// TODO Auto-generated method stub
		
		try {
			byte br[]= file.getBytes();
			BufferedOutputStream bo = new BufferedOutputStream (new FileOutputStream(path+"\\"+name));
		try {
			bo.write(br);
			bo.flush();
			bo.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public List priceBetween(double min, double max) {
		// TODO Auto-generated method stub
		HibernateConnection hc = new HibernateConnection();
		Session ses=hc.getSession();
		Criteria c= ses.createCriteria(Pet.class);
		c.add(Restrictions.between("price", min, max));
		List l=c.list();
		return l;
	}

	@Override
	public List byAge(int min, int max) {
		// TODO Auto-generated method stub
		HibernateConnection hc = new HibernateConnection();
		Session ses = hc.getSession();
		Criteria c  = ses.createCriteria(Pet.class);
		c.add(Restrictions.between("age", min, max));
		List l= c.list();
		return l;
	}

	@Override
	public Pet viewPetdetails(String petname) {
		// TODO Auto-generated method stub
		HibernateConnection hc = new HibernateConnection();
		Session ses = hc.getSession();
		Criteria c= ses.createCriteria(Pet.class);
		c.add(Restrictions.eq("name", petname));
		List l= c.list();
	    Pet p = (Pet) l.get(0);
		
		return p;
	}



}
