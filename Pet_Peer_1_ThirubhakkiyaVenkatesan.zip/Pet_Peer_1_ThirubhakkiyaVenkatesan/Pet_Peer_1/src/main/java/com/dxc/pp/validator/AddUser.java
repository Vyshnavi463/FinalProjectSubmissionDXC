package com.dxc.pp.validator;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.dxc.pp.hib.HibernateConnection;
import com.dxc.pp.model.User;

public class AddUser {
	Session ses;
	public void adduser(User user) {
		HibernateConnection hc= new HibernateConnection();
		ses=hc.getSession();
		ses.save(user);
		Transaction t= ses.beginTransaction();
		t.commit();
		
	}

}
