package com.dxc.pp.validator;

import java.util.Iterator;
import java.io.File;
import java.util.List;
import java.util.Set;

import org.apache.commons.fileupload.FileItem;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.dxc.pp.hib.HibernateConnection;
import com.dxc.pp.model.Pet;
import com.dxc.pp.model.User;

public class UserService {
	public List getMyPets(String username) {
	HibernateConnection hc = new HibernateConnection();
	Session ses = hc.getSession();
	Criteria c =ses.createCriteria(Pet.class);
	c.add(Restrictions.eq("owner",username));
	List l= c.list();
	
	return l;
	}
	
	public void imageUpload(List<FileItem> l) {
		String filePath="C:\\\\\\\\upload";
		for(FileItem f:l) {
			String name= new File(f.getName()).getName();
			try {
				f.write(new File(filePath+File.separator+name));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	public void petDetail(String petname,String username) {
		HibernateConnection hc = new HibernateConnection();
		Session ses = hc.getSession();
		Criteria c = ses.createCriteria(Pet.class);
		c.add(Restrictions.eq("name", petname));
		List<Pet> l =c.list();
		/*
		 * System.out.println(l.size()); for(Pet s:l) { System.out.println(s);
		 * 
		 * }
		 */
		Pet p= (Pet) l.get(0);
		Criteria c1= ses.createCriteria(User.class);
		c1.add(Restrictions.eq("username", username));
		List<User> l1= c1.list();
		
		User u = l1.get(0);
		Pet p1 = (Pet) ses.load(Pet.class, p.getId());
		p.setOwner(u.getUsername());
		p.setEmail(u.getEmail());
		p.setPhno(u.getPhno());
		ses.update(p);
		Transaction t = ses.beginTransaction();
		t.commit();
		System.out.println("here");
		
		
		
		
	}
}
