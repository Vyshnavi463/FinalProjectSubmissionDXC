package com.dxc.pp.action.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

public interface PetsAppService {
	public ModelAndView addUser(String userName,String userPassword,String email,String phno);
	public ModelAndView authenticateUser(String userName,String userPassword);

	public ModelAndView myPets(HttpSession session);
	public ModelAndView viewPetlist(HttpSession session);
	
	public ModelAndView showBybreed(String breed);
	public ModelAndView byLocation(String location);
	public ModelAndView priceBetween(double max);
	public ModelAndView priceBetween(int max);
	public ModelAndView viewPetdetails(String petName,HttpSession session);
	
	
	
	public ModelAndView addPet(String name, int age, String place, String owner, String breeds, String animal, String email,
			String phno, double price, CommonsMultipartFile file1, CommonsMultipartFile file2, HttpSession session);
	ModelAndView petBuy(String petname, HttpSession session);
	
	
	
}
