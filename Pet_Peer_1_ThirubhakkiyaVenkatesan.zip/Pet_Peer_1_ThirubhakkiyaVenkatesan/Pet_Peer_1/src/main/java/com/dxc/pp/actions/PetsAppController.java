package com.dxc.pp.actions;

import java.io.BufferedOutputStream;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.pp.action.service.PetsAppService;
import com.dxc.pp.model.Pet;
import com.dxc.pp.model.User;
import com.dxc.pp.validator.AddUser;
import com.dxc.pp.validator.PetService;
import com.dxc.pp.validator.SecurityService;
import com.dxc.pp.validator.UserService;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

@Controller

public class PetsAppController implements   PetsAppService{

	@Override
	@RequestMapping(value="/user/add")
	public ModelAndView addUser(@RequestParam(value="username")String userName, @RequestParam(value="password")String userPassword,@RequestParam(value="email")String email,@RequestParam(value="phno")String phno) {
		// TODO Auto-generated method stub
		//user registration
		User u =new User();
		u.setUsername(userName);
		u.setUserPassword(userPassword);
		u.setEmail(email);
		u.setPhno(phno);
		AddUser au=new AddUser();
	    au.adduser(u);
		
		return new ModelAndView("adduser");
		}
	
	@Override
	@RequestMapping(value="/user/authenticate",method=RequestMethod.POST)
	public ModelAndView authenticateUser(@RequestParam(value="username")String userName,@RequestParam(value="password")String userPassword) {
		// TODO Auto-generated method stub
		//login validation
		SecurityService s = new SecurityService();
				boolean t=s.authenticateUser(userName, userPassword);
				
		if(t) {
			
			return new ModelAndView("pets","data",userName);
			
		}
		else
			return new ModelAndView("login");
		
		
		
	}
	@Override
	@RequestMapping(value="/pets/addPet",method=RequestMethod.POST)
	public ModelAndView addPet(@RequestParam(value="Name")String name,@RequestParam(value="Age")int age,@RequestParam(value="Place")String place,@RequestParam(value="Owner")String owner,@RequestParam(value="Breeds")String breeds,
			@RequestParam(value="Animal")String animal,@RequestParam(value="Email")String email,@RequestParam(value="Phno")String phno,@RequestParam(value="Price")double price,
			@RequestParam(value="img1") CommonsMultipartFile file1,@RequestParam(value="img2") CommonsMultipartFile file2,HttpSession session) {
		// TODO Auto-generated method stub
		//adding new pets to database
		PetService ps = new PetService();
		Pet p= new Pet();
		p.setName(name);
		p.setAge(age);
		p.setPlace(place);
		p.setOwner(owner);
		p.setBreeds(breeds);
		p.setAnimal(animal);
		p.setEmail(email);
		p.setPhno(phno);
		p.setPrice(price);
		ps.savePet(p);
		/*
		 * List<FileItem> fl ; DiskFileItemFactory dc = new DiskFileItemFactory(); try {
		 * fl= new ServletFileUpload(dc). UserService us = new UserService();
		 * us.imageUpload(fl); } catch (FileUploadException e) { // TODO Auto-generated
		 * catch block e.printStackTrace(); }
		 */
		//System.out.print("here");
		//uploading the image
		String path=session.getServletContext().getRealPath("\\\\\\");
		//String path="C:\\upload";
		String name1= file1.getOriginalFilename();
		
		
		System.out.print(path+"\\"+name1);
		String name2=file2.getOriginalFilename();
		
		/*
		 * try { byte br[]= file.getBytes(); BufferedOutputStream bo = new
		 * BufferedOutputStream (new FileOutputStream(path+"\\"+name1)); try {
		 * bo.write(br); bo.flush(); bo.close(); } catch (IOException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); } } catch
		 * (FileNotFoundException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */
		ps.imgUpload(path, name1, file1);
		ps.imgUpload(path, name2, file2);
		//list of added pets
		File filepath =new File(path);
		File[] f= filepath.listRoots();
		String[] s=filepath.list();
		session.setAttribute("file", s);
		for(File o:f) {
			System.out.print(o);
		}
		List l=ps.getAllPets();
		return new ModelAndView("pets_home","data",l);
		
	}
	@Override
	@RequestMapping(value="/pets/mypets")
	public ModelAndView myPets(HttpSession session) {
		
		// TODO Auto-generated method stub
		String user=(String) session.getAttribute("user");
		UserService u = new UserService();
		List l=u.getMyPets(user);
		
	
		return new ModelAndView("my_pets","data",l);
	}

	@Override
	@RequestMapping(value="/viewpets")
	public ModelAndView viewPetlist(HttpSession session) {
		// TODO Auto-generated method stub
		PetService ps = new PetService();
		List l=ps.getAllPets();
		return new ModelAndView("petlist","data",l);
	}

	@Override
	@RequestMapping(value="/pets/showbybreed")
	public ModelAndView showBybreed(@RequestParam(value="breed")String breed) {
		// TODO Auto-generated method stub
		PetService ps= new PetService();
		List c = ps.sortBybreed(breed);
		
		return new ModelAndView("bybreed","data",c);
	}

	@Override
	@RequestMapping(value="/pets/bylocation")
	public ModelAndView byLocation(@RequestParam(value="location")String location) {
		// TODO Auto-generated method stub
		PetService ps= new PetService();
		List l=ps.byLocation(location);
		return new ModelAndView("showbylocation","data",l);
	}

	@Override
	@RequestMapping(value="/pets/byprice")
	public ModelAndView priceBetween(@RequestParam(value="max")double max) {
		// TODO Auto-generated method stub
		PetService ps = new PetService();
		List l=ps.priceBetween(0, max);
		return new ModelAndView("byprice","data",l);
	}

	@Override
	@RequestMapping(value="/pets/byage")
	public ModelAndView priceBetween(@RequestParam(value="max")int max) {
		// TODO Auto-generated method stub
		PetService ps = new PetService();
		List d = ps.byAge(0, max);
		return new ModelAndView("byage","data",d);
	}

	@Override
	@RequestMapping(value="/pets/buy")
	public ModelAndView petBuy(@RequestParam(value="petname")String petname, HttpSession session) {
		// TODO Auto-generated method stub
		String user = (String) session.getAttribute("username");
		System.out.println(user);
		UserService us = new UserService();
		us.petDetail(petname, user);
		
		return new ModelAndView("buy");
	}

	@Override
	@RequestMapping(value="/pets/viewdetails")
	public ModelAndView viewPetdetails(@RequestParam(value="petname")String petName, HttpSession session) {
		// TODO Auto-generated method stub
		PetService ps = new PetService();
		Pet p=ps.viewPetdetails(petName);
		File filepath =new File("C:\\\\upload");
		String[] path = filepath.list();
		session.setAttribute("file", path);
		
		return new ModelAndView("viewpetdetail","view",p);
	}

	

}
