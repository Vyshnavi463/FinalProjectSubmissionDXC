package com.dxc.pp.validator.service;

import java.util.List;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.dxc.pp.model.Pet;

public interface Petservice {
	public void savePet(Pet pet);
	public List getAllPets();
	
	public List sortBybreed(String breed);
	public List byLocation(String location);
	
	public void imgUpload(String path, String name, CommonsMultipartFile file);
	public List priceBetween(double min,double max);
	public List byAge(int min,int max);
	public Pet viewPetdetails(String petname);

}
