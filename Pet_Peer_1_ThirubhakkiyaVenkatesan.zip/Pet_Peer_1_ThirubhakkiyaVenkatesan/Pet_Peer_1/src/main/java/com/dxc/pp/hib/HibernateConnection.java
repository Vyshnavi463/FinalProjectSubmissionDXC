package com.dxc.pp.hib;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class HibernateConnection {
	Session session;
	public Session getSession() {
		return session;
	}
	public HibernateConnection(){
		SessionFactory sfact= new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory();
		 session=sfact.openSession();
		
	}

}
